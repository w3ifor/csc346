import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class assignment2Test {
    public static final double DELTA=0.01;
    @Test
    void askDistance() {

    }

    @Test
    void askZipCode() {


    }

    @Test
    void haversine() {
        assertEquals(117.96,assignment2.haversine(40.45,-94.84,41.50,-94.64),DELTA);
    }
}